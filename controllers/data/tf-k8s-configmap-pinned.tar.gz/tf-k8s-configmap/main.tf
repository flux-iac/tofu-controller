variable "kubeconfig" {}
variable "context" {}
variable "config_name" {}

provider "kubernetes" {
  config_path    = var.kubeconfig
  config_context = var.context
}

resource "kubernetes_config_map_v1" "example" {

  metadata {
    name = var.config_name
  }

  data = {
    api_host = "myhost:443"
    db_host  = "dbhost:5432"
  }

}

output "api_host" {
  value = kubernetes_config_map_v1.example.data.api_host
}

terraform {
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "3.4.0"
    }
  }
}
