#!/bin/bash

# Exit if any of the intermediate steps fail
set -e

jq -n --arg httpProxy "${HTTP_PROXY}" --arg httpsProxy "${HTTPS_PROXY}" --arg noProxy "${NO_PROXY}" '{"http_proxy": $httpProxy, "https_proxy": $httpsProxy, "no_proxy": $noProxy}'
