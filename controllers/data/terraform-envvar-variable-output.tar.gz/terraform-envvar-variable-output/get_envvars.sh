#!/bin/bash

# Exit if any of the intermediate steps fail
set -e

cat <<EOT
{"http_proxy": "${HTTP_PROXY}", "https_proxy": "${HTTPS_PROXY}", "no_proxy": "${NO_PROXY}"}
EOT
