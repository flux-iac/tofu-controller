#!/bin/bash

# Exit if any of the intermediate steps fail
set -e

cat <<EOT
{"vault_token": "${VAULT_TOKEN}"}
EOT
